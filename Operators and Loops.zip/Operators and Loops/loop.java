//write a program to print numbers from 1 to 10:

import java.util.*;

public class loop{
    public static void main(String[] args){
        for(int i=1;i<11;i++){
            System.out.println(i);
        }

    }
}